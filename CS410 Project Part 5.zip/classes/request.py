# Request class - implements singleton design pattern
class Request:

    # Converts a query into a request
    def __convert_query(self, query):

        # convert query
        request = query

        # return result
        return request