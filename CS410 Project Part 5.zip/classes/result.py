# Result class - implements singleton and iterator design patterns
class Result:

    # Determine which graph to display based on the selected data Topic
    def get_graph_type(self, data_topic):
        graph_type = data_topic
        return graph_type

    # Send request to API and return result
    def get_result(self, request):
        result = request
        return Result
        