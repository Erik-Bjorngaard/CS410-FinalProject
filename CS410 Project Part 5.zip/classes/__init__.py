from request import Request
from result import Result